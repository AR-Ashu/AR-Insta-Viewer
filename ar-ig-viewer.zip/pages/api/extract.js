export default function handler(req, res) {
  if (req.method === "POST") {
    const { source } = req.body;
    const links = [];
    const regex = /https:\/\/[^"]+\.(jpg|mp4)/g;
    const matches = source.match(regex);
    if (matches) {
      matches.forEach(link => {
        if (!links.includes(link)) links.push(link);
      });
    }
    res.status(200).json({ media: links });
  } else {
    res.status(405).json({ error: "Method not allowed" });
  }
}