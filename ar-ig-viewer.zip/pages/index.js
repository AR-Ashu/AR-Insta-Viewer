import { useState } from "react";
import Head from "next/head";

export default function Home() {
  const [url, setUrl] = useState("");
  const [source, setSource] = useState("");
  const [mediaLinks, setMediaLinks] = useState([]);
  const [loading, setLoading] = useState(false);

  const extractMedia = async () => {
    setLoading(true);
    setMediaLinks([]);
    const res = await fetch("/api/extract", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url, source }),
    });
    const data = await res.json();
    setMediaLinks(data.media || []);
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-black text-white px-4 py-8 font-mono">
      <Head>
        <title>AR Ig Viewer</title>
      </Head>
      <div className="max-w-3xl mx-auto">
        <h1 className="text-3xl font-bold mb-6">AR Ig Viewer | Instagram Private Downloader</h1>
        <ol className="list-decimal ml-6 text-gray-400 mb-4">
          <li>Login to Instagram and open the private post.</li>
          <li>Right-click → View Page Source → Copy all.</li>
          <li>Paste below to extract media.</li>
        </ol>
        <input
          className="w-full bg-gray-900 p-2 mb-4 border border-gray-700 rounded"
          placeholder="Paste Instagram post URL here"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
        />
        <textarea
          className="w-full h-48 bg-gray-900 p-2 mb-4 border border-gray-700 rounded"
          placeholder="Paste full page source here"
          value={source}
          onChange={(e) => setSource(e.target.value)}
        />
        <button
          className="bg-green-500 text-black px-4 py-2 rounded hover:bg-green-600"
          onClick={extractMedia}
        >
          {loading ? "Extracting..." : "Extract Media"}
        </button>

        {mediaLinks.length > 0 && (
          <div className="mt-6">
            <h2 className="text-xl mb-2">Download Links</h2>
            <ul className="space-y-2">
              {mediaLinks.map((link, idx) => (
                <li key={idx}>
                  <a
                    href={link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-400 underline"
                  >
                    Download {link.endsWith(".mp4") ? "Video" : "Image"} {idx + 1}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </div>
  );
}